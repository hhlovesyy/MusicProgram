package view;

import cn.itheima.media.PlayBean;
import cn.itheima.utils.ImageUtils;
import cn.itheima.utils.XMLUtils;
//import com.sun.deploy.panel.AndOrRadioPropertyGroup;
//import com.sun.javafx.scene.control.skin.LabeledSkinBase;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.Bloom;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import org.jaudiotagger.audio.exceptions.CannotReadException;
import org.jaudiotagger.audio.exceptions.InvalidAudioFrameException;
import org.jaudiotagger.audio.exceptions.ReadOnlyFileException;
import org.jaudiotagger.audio.mp3.MP3AudioHeader;
import org.jaudiotagger.audio.mp3.MP3File;
import org.jaudiotagger.tag.TagException;
import org.jaudiotagger.tag.id3.AbstractID3v2Frame;
import org.jaudiotagger.tag.id3.AbstractID3v2Tag;
import org.jaudiotagger.tag.id3.framebody.FrameBodyAPIC;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
public class MusicHallPane extends BorderPane {	
	//private Label curmusicGroup;
	private Image backimage;
	private ImageView backImageView;	
	private ImageView TOP10ImageView;
	private Label labelTOP10ImageView;
	private ImageView ImageViewRecommendSongList;
	private Label labelRecommendSongList;
	private ImageView ImageViewRecommendAlbum;
	private Label labelRecommendAlbum;
	private Label labMusicHall;
	//private Label lab_name;
	//private Label lab_follow;
	//private Label lab_fans;
	private Label lab_groupmusic,lab_playg,lab_addg,lab_delg;
	private Label lab6,lab_createalbum ;
	private Label labLine;
	private AnchorPane anchorPane1;
	private ScrollPane scrollPane;
	private Label lab_creategroup;
	private VBox groupVBox;
	private VBox groupVBox1;
	private VBox vBox;
	private TableView<PlayBean> tableView;

	public MusicHallPane()
	{


		//1.读取上次关闭时，播放的歌单和歌曲
		String[] playInfo = XMLUtils.readPrevPlayInfo();

		//2.音乐馆：标签
		labMusicHall = new Label("音乐馆");
		labMusicHall.setFont(new Font("黑体",30));
		labMusicHall.setTextFill(Color.WHITE);//文字：白色

		labMusicHall.setLayoutX(30);
		labMusicHall.setLayoutY(10);
		labMusicHall.setPrefWidth(100);
		labMusicHall.setPrefHeight(30);
		labMusicHall.setAlignment(Pos.CENTER);
		//绽放效果
		Bloom bloomMusicHall=new Bloom();
		bloomMusicHall.setThreshold(0.3);
		labMusicHall.setEffect(bloomMusicHall);


		//3.背景
		backimage = new Image("img/starry_sky.png");
		backImageView= new ImageView();
		backImageView = new ImageView(backimage);
		backImageView.setLayoutX(0);
		backImageView.setLayoutY(0);
		backImageView.setFitWidth(1040);
		backImageView.setFitHeight(300);
		//改变图片透明度
		//backImageView.setStyle("-fx-opacity: 0.25;-fx-background-color: transparent;");
		backImageView.setOpacity(5);
		//高斯模糊
		GaussianBlur gaussianBlur = new GaussianBlur();
		gaussianBlur.setRadius(63);
		backImageView.setEffect(gaussianBlur);


		//4.TOP10
		TOP10ImageView=  new ImageView("img/TOP10.png");
		TOP10ImageView.setFitWidth(160);
		TOP10ImageView.setFitHeight(160);
		labelTOP10ImageView= new Label("",TOP10ImageView);
		labelTOP10ImageView.setLayoutX(70);
		labelTOP10ImageView.setLayoutY(80);
		
		//5.推荐歌单
		ImageViewRecommendSongList=  new ImageView("img/RecommendedSongList.png");
		ImageViewRecommendSongList.setFitWidth(160);
		ImageViewRecommendSongList.setFitHeight(160);
		labelRecommendSongList= new Label("",ImageViewRecommendSongList);
		labelRecommendSongList.setLayoutX(300);
		labelRecommendSongList.setLayoutY(80);
		
		//6.推荐专辑
		ImageViewRecommendAlbum=  new ImageView("img/RecommendedAlbum.png");
		ImageViewRecommendAlbum.setFitWidth(160);
		ImageViewRecommendAlbum.setFitHeight(160);
		labelRecommendAlbum= new Label("",ImageViewRecommendAlbum);
		labelRecommendAlbum.setLayoutX(530);
		labelRecommendAlbum.setLayoutY(80);



		//7.歌单列表标签
		lab_groupmusic = new Label("歌单列表");
		lab_groupmusic.setPrefWidth(80);
		lab_groupmusic.setPrefHeight(25);
		lab_groupmusic.setTextFill(Color.WHITE);
		lab_groupmusic.setAlignment(Pos.CENTER);
		lab_groupmusic.setBackground(new Background(new BackgroundFill(Color.rgb(180,0,0),null,null)));
		lab_groupmusic.setLayoutX(255);
		lab_groupmusic.setLayoutY(275);

		//8.一条红线：Label
		labLine = new Label();
		labLine.setMinHeight(0);
		labLine.setPrefHeight(2);
		labLine.setBackground(new Background(new BackgroundFill(Color.rgb(180,0,0),null,null)));
		labLine.setLayoutX(0);
		labLine.setLayoutY(lab_groupmusic.getLayoutY() + lab_groupmusic.getPrefHeight());

		//上侧的ScrollPane
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
		scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
		scrollPane.setPadding(new Insets(0,0,0,0));
		scrollPane.setContent(anchorPane1);
		scrollPane.setPrefHeight(304);
		scrollPane.setMouseTransparent(true);//使ScrollPane不接收鼠标事件


		//个人信息部分面板AnchorPane1
		AnchorPane anchorPane1 = new AnchorPane();
		anchorPane1.setBackground(new Background(new BackgroundFill(Color.BLACK,null,null)));
		anchorPane1.getChildren().addAll(backImageView, labMusicHall,labelRecommendSongList,
				labelRecommendAlbum, lab_groupmusic,labLine, labelTOP10ImageView/* ,curmusicGroup */);
		anchorPane1.prefWidthProperty().bind(scrollPane.widthProperty());
		anchorPane1.prefHeightProperty().bind(scrollPane.heightProperty()); 
		labLine.prefWidthProperty().bind(scrollPane.widthProperty());


		//*******************************上侧完毕***********************************************//
		//*******************************下侧：歌单列表******************************************//

		//1.推荐歌单：Lable
		Label labRecommendSongList = new Label("推荐歌单");
		labRecommendSongList.setPrefWidth(220);
		labRecommendSongList.setPrefHeight(20);
		labRecommendSongList.setTextFill(Color.rgb(160,160,160));

		//2.+符号：ImageView
		ImageView v2 = new ImageView("img/left/create_2_Dark.png");
		v2.setFitWidth(15);
		v2.setPreserveRatio(true);

		lab_creategroup = new Label("", v2);
		lab_creategroup.setPrefWidth(15);
		lab_creategroup.setPrefHeight(15);
		lab_creategroup.setOnMouseEntered(e -> v2.setImage(new Image("img/left/create_2.png")));
		lab_creategroup.setOnMouseExited(e -> v2.setImage(new Image("img/left/create_2_Dark.png")));

		//封装4和5的控件的HBox(水平布局)
		HBox hBox = new HBox(5);
		hBox.getChildren().addAll(labRecommendSongList, lab_creategroup);

		//将1,2,3，(4,5)HBox封装到一个VBox中
		VBox vBox = new VBox(15);//15表示元素之间的间距
		vBox.setPrefWidth(255);
		vBox.setPrefHeight(40);
		vBox.setPadding(new Insets(5, 5, 5, 10));
		vBox.getChildren().addAll( hBox);

		List<String> groupList = XMLUtils.readAllGroup();
		//将每个"歌单名字"封装为一个"HBox"对象
		List<HBox> hBoxList = new ArrayList<>();
		for (String groupName : groupList) {
			//1.心形图标：ImageView
			ImageView iv1 = new ImageView("img/left/xinyuanDark.png");
			iv1.setFitWidth(15);
			iv1.setPreserveRatio(true);
			Label lab_heart = new Label("", iv1);
			lab_heart.setMinWidth(0);
			lab_heart.setMinHeight(0);
			lab_heart.setPrefWidth(15);
			lab_heart.setPrefHeight(15);
			lab_heart.setOnMouseEntered(e -> iv1.setImage(new Image("img/left/xinyuan.png")));
			lab_heart.setOnMouseExited(e -> iv1.setImage(new Image("img/left/xinyuanDark.png")));


			//2.歌单名称：Label			
			Label labGroupName = new Label(groupName);
			labGroupName.setMinHeight(0);
			labGroupName.setPrefHeight(15);
			labGroupName.setPrefWidth(150);
			labGroupName.setTextFill(Color.rgb(210,210,210));
			labGroupName.setOnMouseEntered(e -> labGroupName.setTextFill(Color.WHITE));
			labGroupName.setOnMouseExited(e -> labGroupName.setTextFill(Color.rgb(210,210,210)));


			//3.播放图片：ImageView
			ImageView iv2 = new ImageView("img/left/volumn_1_Dark.png");
			iv2.setFitWidth(15);
			iv2.setFitHeight(15);
			lab_playg= new Label("", iv2);
			lab_playg.setMinWidth(0);
			lab_playg.setMinHeight(0);
			lab_playg.setPrefWidth(15);
			lab_playg.setPrefHeight(15);
			lab_playg.setOnMouseEntered(e -> iv2.setImage(new Image("img/left/volumn_1.png")));
			lab_playg.setOnMouseExited(e -> iv2.setImage(new Image("img/left/volumn_1_Dark.png")));


			//4.+符号：ImageView
			ImageView iv3 = new ImageView("img/left/addDark.png");
			iv3.setFitWidth(15);
			iv3.setFitHeight(15);
			lab_addg = new Label("", iv3);
			lab_addg.setMinWidth(0);
			lab_addg.setMinHeight(0);
			lab_addg.setPrefWidth(15);
			lab_addg.setPrefHeight(15);
			lab_addg.setOnMouseEntered(e -> iv3.setImage(new Image("img/left/add.png")));
			lab_addg.setOnMouseExited(e -> iv3.setImage(new Image("img/left/addDark.png")));


			//5.垃圾桶符号：ImageView
			ImageView iv4 = new ImageView("img/left/laji_1_Dark.png");
			iv4.setFitWidth(15);
			iv4.setFitHeight(15);
			lab_delg = new Label("", iv4);
			lab_delg.setMinWidth(0);
			lab_delg.setMinHeight(0);
			lab_delg.setPrefWidth(15);
			lab_delg.setPrefHeight(15);
			lab_delg.setOnMouseEntered(e -> iv4.setImage(new Image("img/left/laji_1.png")));
			lab_delg.setOnMouseExited(e -> iv4.setImage(new Image("img/left/laji_1_Dark.png")));


			HBox hBox1 = new HBox(10);
			hBox1.getChildren().addAll(lab_heart, labGroupName, lab_playg, lab_addg, lab_delg);
			hBox1.setPadding(new Insets(5,5,5,10));

			hBoxList.add(hBox1);


		}

		//6.推荐专辑：Lable
		Label labRecommendAlbum = new Label("推荐专辑");
		labRecommendAlbum.setPrefWidth(220);
		labRecommendAlbum.setPrefHeight(20);
		labRecommendAlbum.setTextFill(Color.rgb(160,160,160));

		//7.+符号：ImageView
		ImageView v3 = new ImageView("img/left/create_2_Dark.png");
		v3.setFitWidth(15);
		v3.setPreserveRatio(true);

		lab_createalbum = new Label("", v3);
		lab_createalbum.setPrefWidth(15);
		lab_createalbum.setPrefHeight(15);
		lab_createalbum.setOnMouseEntered(e -> v3.setImage(new Image("img/left/create_2.png")));
		lab_createalbum.setOnMouseExited(e -> v3.setImage(new Image("img/left/create_2_Dark.png")));
		lab_createalbum.setOnMouseClicked(e -> {
			//创建一个新的舞台

		});

		//封装6和7的控件的HBox(水平布局)
		HBox hBox1 = new HBox(5);
		hBox1.getChildren().addAll(labRecommendAlbum, lab_createalbum);
		
		//封装6和7的控件的HBox(水平布局)
		//将1,2,3，(4,5)HBox封装到一个VBox中
		VBox vBox1 = new VBox(70);//15表示元素之间的间距
		vBox1.setPrefWidth(255);
		vBox1.setPrefHeight(40);
		vBox1.setPadding(new Insets(5, 5, 5, 10));
		vBox1.getChildren().addAll( hBox1);

		//歌曲信息
		tableView = new TableView<>();
		tableView.setPrefWidth(50);
		tableView.getStylesheets().add("css/playTable.css");

		TableColumn c1 = new TableColumn("序号");
		c1.setPrefWidth(80);
		c1.setCellValueFactory(new PropertyValueFactory<>("id"));

		TableColumn c2 = new TableColumn("音乐标题");
		c2.setPrefWidth(150);
		c2.setCellValueFactory(new PropertyValueFactory<>("soundName"));

		TableColumn c3 = new TableColumn("歌手");
		c3.setPrefWidth(130);
		c3.setCellValueFactory(new PropertyValueFactory<>("artist"));

		TableColumn c4 = new TableColumn("专辑");
		c4.setPrefWidth(150);
		c4.setCellValueFactory(new PropertyValueFactory<>("album"));

		TableColumn c5 = new TableColumn("大小");
		c5.setPrefWidth(100);
		c5.setCellValueFactory(new PropertyValueFactory<>("length"));

		TableColumn c6 = new TableColumn("时间");
		c6.setPrefWidth(100);
		c6.setCellValueFactory(new PropertyValueFactory<>("time"));

		TableColumn c7 = new TableColumn("操作");
		c7.setPrefWidth(100);
		c7.setCellValueFactory(new PropertyValueFactory<>("labDelete"));



		tableView.getColumns().addAll(c1,c2,c3,c4,c5,c6,c7);


		tableView.setRowFactory(tv -> {
			TableRow<PlayBean> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				//验证双击

			});
			return row;
		});

		//**************************************总的BorderPane********************************//
		Image backImageSongList = new Image("img/starry_sky.png");
		ImageView backSongListImageView = new ImageView();
		backSongListImageView = new ImageView(backImageSongList);
		backSongListImageView.setLayoutX(0);
		backSongListImageView.setLayoutY(0);
		backSongListImageView.setFitWidth(255);
		backSongListImageView.setFitHeight(500);
		//改变图片透明度
		//backImageView.setStyle("-fx-opacity: 0.25;-fx-background-color: transparent;");
		backImageView.setOpacity(5);
		//高斯模糊
		GaussianBlur gaussianBlurSongList = new GaussianBlur();
		gaussianBlurSongList.setRadius(63);
		backSongListImageView.setEffect(gaussianBlurSongList);

		AnchorPane anchorPane2 = new AnchorPane();
		this.setTop(anchorPane1);	
		//        anchorPane1.getChildren().addAll
		//        BorderPane leftPane = new BorderPane();
		//        
		//        leftPane.setTop(vBox);
		//        leftPane.setCenter(groupVBox);
		//        leftPane.setCenter(vBox1);
		vBox.setLayoutX(0);
		vBox.setLayoutY(0);

		groupVBox = new VBox(10);
        groupVBox.setPrefWidth(255);
        groupVBox.setPadding(new Insets(10,0,0,15));
        for (HBox hb : hBoxList) {
            groupVBox.getChildren().add(hb);
        }
	
		groupVBox.setLayoutX(0);
		groupVBox.setLayoutY(30);

		vBox1.setLayoutX(0);
		vBox1.setLayoutY(230);
	
		//        groupVBox1.setLayoutX(0);
		//        groupVBox1.setLayoutY(200);
		anchorPane2.getChildren().addAll(backSongListImageView,vBox,groupVBox,vBox1);

		this.setLeft(anchorPane2);
		this.setCenter(tableView);

		//**************************************监听事件********************************//
//		//关注
//		lab_follow.setOnMouseClicked(e -> {
//
//		});
//
//
//		//粉丝
//		lab_fans.setOnMouseClicked(e -> {
//
//		});

		//添加歌单的+符号：
		lab_creategroup.setOnMouseClicked(e -> {

		});

		//歌单小喇叭
		lab_playg.setOnMouseClicked(e -> {

		});

		//添加歌曲+符号
		lab_addg.setOnMouseClicked(e -> {

		});


		//垃圾桶符号,删除歌曲
		lab_delg.setOnMouseClicked(e -> {

		});


		//点击右侧歌曲
		tableView.setOnMouseClicked(e -> {

		});

		//添加专辑的+符号：
		lab_createalbum.setOnMouseClicked(e -> {

		});
	}

//	public Label getLab_follow() {
//		return lab_follow;
//	}
//
//	public void setLab_follow(Label lab_follow) {
//		this.lab_follow = lab_follow;
//	}
//
//
//	public Label getLab_fans() {
//		return lab_fans;
//	}
//
//	public void setLab_fans(Label lab_fans) {
//		this.lab_fans = lab_fans;
//	}


	public Label getLab_playg() {
		return lab_playg;
	}

	public void setLab_playg(Label lab_playg) {
		this.lab_playg = lab_playg;
	}


	public Label getLab_addg() {
		return lab_addg;
	}

	public void setLab_addg(Label lab_addg) {
		this.lab_addg = lab_addg;
	}


	public Label getLab_delg() {
		return lab_delg;
	}

	public void setLab_delg(Label lab_delg) {
		this.lab_delg = lab_delg;
	}


	public Label getLab_createalbum() {
		return lab_createalbum;
	}

	public void setLab_createalbum(Label lab_createalbum) {
		this.lab_createalbum = lab_createalbum;
	}



	public Label getLab_creategroup() {
		return lab_creategroup;
	}

	public void setLab_creategroup(Label lab_creategroup) {
		this.lab_creategroup = lab_creategroup;
	}

	//**************************************set,get********************************//


}
